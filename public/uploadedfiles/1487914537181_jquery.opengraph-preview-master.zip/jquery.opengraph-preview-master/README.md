# jQuery.opengraph-preview
jQuery plugin for displaying OpenGraph metadata embedded in webpages

## Contribute

You must install [`npm`](https://www.npmjs.com/) before start constributing.

    git clone https://github.com/AugierLe42e/jquery.opengraph-preview.git && cd jquery.opengraph-preview
    npm install

You can run unit tests using command

    npm test
